from ray import serve
import gradio as gr

from fastapi import FastAPI
app = FastAPI()

io = gr.Interface(fn=lambda x: x, inputs="text", outputs="text")
gr_app = gr.mount_gradio_app(app, io, path='/gradio')

@serve.deployment
@serve.ingress(app)
class CustomApp:
    def __init__(self):
        pass

# MODEL BIND AS A SERVICE
app = CustomApp.bind()