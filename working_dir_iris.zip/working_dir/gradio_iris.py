from ray.serve.gradio_integrations import GradioServer
import gradio as gr
import requests
import json

def ui_builder():

    def model_infer(input):
        URL = f"http://10.96.192.151/v2/models/iris/infer"
        response = requests.post(URL, json=json.loads(input))
        return response.json()['outputs']

    infer_example = '''{
            "inputs": [
                {
                    "name": "predict",
                    "shape": [2, 4],
                    "datatype": "FP32",
                    "data": [
                        [7.8, 2.8, 6.8, 3.4],
                        [6.0, 3.4, 4.5, 1.6]
                    ]
                }
            ]
        }'''

    return gr.Interface(
        fn=model_infer,
        inputs=[
            gr.Textbox(infer_example, label="Входной вектор")
        ],
        outputs=[
            gr.JSON(label="Ответ модели")
        ],
        flagging_options=[],
        theme=gr.themes.Soft(),
        title="Gradio — Демо",
        clear_btn=gr.Button("Очистить", variant="secondary"),
        submit_btn=gr.Button("Отправить", variant="primary"),
        description='''Демонстрационный интерфейс для тестового вызова модели iris.''',
        article="<b>&copy; ГАIКА</b> | Команда применения моделей | Обучение",
        css="footer {visibility: hidden}"
    )

app = GradioServer.options(route_prefix="/web", ray_actor_options={"num_cpus": 1}).bind(ui_builder)