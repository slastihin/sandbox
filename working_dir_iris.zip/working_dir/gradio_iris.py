from ray.serve.gradio_integrations import GradioServer
import gradio as gr
import requests
import json

def ui_builder_iris():

    def model_infer(input):
        URL = f"http://10.96.192.151/v2/models/iris/infer"
        response = requests.post(URL, json=json.loads(input))
        return response.json()['outputs']

    infer_example = '''{
            "inputs": [
                {
                    "name": "predict",
                    "shape": [2, 4],
                    "datatype": "FP32",
                    "data": [
                        [7.8, 2.8, 6.8, 3.4],
                        [6.0, 3.4, 4.5, 1.6]
                    ]
                }
            ]
        }'''

    return gr.Interface(
        fn=model_infer,
        inputs=[
            gr.Textbox(infer_example, label="Входной вектор")
        ],
        outputs=[
            gr.JSON(label="Ответ модели")
        ],
        title="Gradio — Демо",
    )

app = GradioServer.options(route_prefix="/iris", ray_actor_options={"num_cpus": 1}).bind(ui_builder_iris)